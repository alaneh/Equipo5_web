<?php
include 'conexion.php';

if ($conn) {
    echo "Conexión exitosa a la base de datos.";
} else {
    echo "Error al conectar: " . $conn->connect_error;
}
?>
