<?php
// Configuración de la base de datos
$host = "localhost";
$usuario = "root";
$clave = ""; // Dejar vacío si no configuraste contraseña
$baseDeDatos = "lockers_e5";

// Crear conexión
$conn = new mysqli($host, $usuario, $clave, $baseDeDatos);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Establecer conjunto de caracteres
$conn->set_charset("utf8mb4");
?>
