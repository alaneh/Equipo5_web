<?php
include 'conexion.php';

// Verificar si se envió una solicitud POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Leer datos enviados como JSON
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input['boleta'])) {
        $boleta = $input['boleta'];

        // Actualizar el estado del registro o solicitud
        $sql = "UPDATE Alumno SET estado = 'Confirmado' WHERE boleta = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $boleta);

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Registro confirmado correctamente."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error al confirmar el registro."]);
        }

        $stmt->close();
    } else {
        echo json_encode(["status" => "error", "message" => "Boleta no proporcionada."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Método no permitido."]);
}

$conn->close();
?>
