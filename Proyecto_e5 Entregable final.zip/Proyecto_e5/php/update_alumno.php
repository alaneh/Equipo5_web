<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $boleta = $_POST['boleta'];
    $nombre = $_POST['nombre'];
    $primerApellido = $_POST['1erApellido'];
    $segundoApellido = $_POST['2doApellido'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];
    $estatura = $_POST['estatura'];
    $usuario = $_POST['usuario'];

    $sql = "UPDATE Alumno SET nombre = ?, 1erApellido = ?, 2doApellido = ?, correo = ?, telefono = ?, estatura = ?, usuario = ? WHERE boleta = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssi", $nombre, $primerApellido, $segundoApellido, $correo, $telefono, $estatura, $usuario, $boleta);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Datos actualizados correctamente."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error al actualizar los datos."]);
    }
}
?>
