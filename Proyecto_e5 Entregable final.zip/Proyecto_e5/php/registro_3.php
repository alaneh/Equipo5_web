<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $boleta = $_POST['boleta'];
    $horario = $_FILES['horario'] ?? null;
    $credencial = $_FILES['credencial'] ?? null;

    if ($horario && $horario['tmp_name']) {
        $horarioPath = '../uploads/' . basename($horario['name']);
        move_uploaded_file($horario['tmp_name'], $horarioPath);
        $sql = "UPDATE Alumno SET horario_pdf = ? WHERE boleta = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $horarioPath, $boleta);
        $stmt->execute();
    }

    if ($credencial && $credencial['tmp_name']) {
        $credencialPath = '../uploads/' . basename($credencial['name']);
        move_uploaded_file($credencial['tmp_name'], $credencialPath);
        $sql = "UPDATE Alumno SET credencial_pdf = ? WHERE boleta = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $credencialPath, $boleta);
        $stmt->execute();
    }

    echo "Cambios guardados correctamente.";
}
?>
