<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $boleta = $_POST['boleta'];
    $horario = $_FILES['horario'];
    $credencial = $_FILES['credencial'];

    $horarioPath = '../uploads/' . basename($horario['name']);
    $credencialPath = '../uploads/' . basename($credencial['name']);

    if (move_uploaded_file($horario['tmp_name'], $horarioPath) && move_uploaded_file($credencial['tmp_name'], $credencialPath)) {
        $sql = "UPDATE Alumno SET horario_pdf = ?, credencial_pdf = ? WHERE boleta = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $horarioPath, $credencialPath, $boleta);

        if ($stmt->execute()) {
            header("Location: ../htmls/registro_3.html");
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "Error al subir los archivos.";
    }
}
?>
