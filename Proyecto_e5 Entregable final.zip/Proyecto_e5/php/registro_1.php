<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $boleta = $_POST['boleta'];
    $nombre = $_POST['nombre'];
    $primerApellido = $_POST['1erApellido'];
    $segundoApellido = $_POST['2doApellido'];
    $correo = $_POST['correo'];
    $clave = password_hash($_POST['clave'], PASSWORD_DEFAULT);
    $tipoSolicitud = $_POST['tipoSolicitud'];
    $numeroLocker = $_POST['numeroLocker'] ?? null;

    if ($tipoSolicitud === "Renovación" && !$numeroLocker) {
        die("Error: El número de locker es obligatorio para renovaciones.");
    }

    $sql = "INSERT INTO Alumno (boleta, nombre, 1erApellido, 2doApellido, correo, clave)
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssss", $boleta, $nombre, $primerApellido, $segundoApellido, $correo, $clave);

    if ($stmt->execute()) {
        header("Location: ../htmls/registro_2.html");
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
