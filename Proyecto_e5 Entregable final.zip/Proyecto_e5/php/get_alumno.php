<?php
include 'conexion.php';

if (isset($_GET['boleta'])) {
    $boleta = $_GET['boleta'];
    $sql = "SELECT * FROM Alumno WHERE boleta = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $boleta);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        echo json_encode([
            "status" => "success",
            "tipoSolicitud" => $data['tipo_solicitud'],
            "nombreCompleto" => $data['nombre'] . " " . $data['1erApellido'] . " " . $data['2doApellido'],
            "telefono" => $data['telefono'],
            "correo" => $data['correo'],
            "boleta" => $data['boleta'],
            "estatura" => $data['estatura'],
            "usuario" => $data['usuario'],
            "horario" => $data['horario_pdf'],
            "credencial" => $data['credencial_pdf'],
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Alumno no encontrado."]);
    }
}
?>
