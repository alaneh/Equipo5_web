document.addEventListener("DOMContentLoaded", () => {
const { jsPDF } = window.jspdf; // Acceso a jsPDF

    const conformidadCheckbox = document.getElementById("conformidad");
    const comprobanteInput = document.getElementById("comprobante");
    const generarAcuseBtn = document.getElementById("generar-acuse");

    // Validar si el formulario está completo
    function validarFormulario() {
        const archivoSubido = comprobanteInput.files.length > 0;
        const conformidadMarcada = conformidadCheckbox.checked;

        // Habilitar o deshabilitar el botón
        generarAcuseBtn.disabled = !(archivoSubido && conformidadMarcada);
    }

    // Escuchar cambios en los inputs
    conformidadCheckbox.addEventListener("change", validarFormulario);
    comprobanteInput.addEventListener("change", validarFormulario);

    // Generar PDF
    generarAcuseBtn.addEventListener("click", () => {
        // Datos simulados para pruebas (esto será dinámico en una implementación real)
        const boleta = "2023123456"; // Reemplaza con datos reales
        const nombre = "Juan Pérez López"; // Reemplaza con datos reales
        const casillero = "45"; // Reemplaza con datos reales
        const periodo = "Semestre 2024 - 2025/2 (Febrero - Agosto)";
        const fecha = new Date().toLocaleDateString();

        // Llamar a la función para generar el PDF
        generarPDF(boleta, nombre, casillero, periodo, fecha);
    });

    // Función para generar el PDF
    function generarPDF(boleta, nombre, casillero, periodo, fecha) {
        // Asegúrate de que jsPDF esté correctamente cargado
        if (typeof jsPDF === "undefined") {
            alert("Error: jsPDF no está disponible.");
            return;
        }
            const doc = new jsPDF();
        
            // Agregar logotipos
           // doc.addImage("../imgs/ipn.png", "PNG", 10, 10, 30, 30); // Logo IPN (izquierda)
            //doc.addImage("../imgs/escom.png", "PNG", 170, 10, 30, 30); // Logo ESCOM (derecha)
        
            // Títulos Centrados
            doc.setFont("Helvetica", "bold");
            doc.setFontSize(14);
            doc.text("INSTITUTO POLITÉCNICO NACIONAL", 105, 20, { align: "center" });
            doc.text("ESCUELA SUPERIOR DE CÓMPUTO", 105, 28, { align: "center" });
        
            // Subtítulo
            doc.setFontSize(12);
            doc.text("ASIGNACIÓN DE LOCKER", 105, 36, { align: "center" });
        
            // Línea divisora
            doc.setLineWidth(0.2);
            doc.line(10, 42, 200, 42);
        
            // Fecha
            doc.setFontSize(10);
            doc.setFont("Helvetica", "normal");
            doc.text(`Fecha: ${fecha}`, 10, 50);
            doc.setFontSize(12);
            doc.text(`Se autoriza que utilices el casillero durante el ciclo: ${periodo}`, 10, 60);
            doc.text("El uso del casillero será para resguardar material bibliográfico, académico, de laboratorio, deportivo,", 10, 70);
            doc.text("cultural y lo relacionado con tu actividad como estudiante dentro de la escuela.", 10, 80);
            doc.text("Cualquier incumplimiento de la normativa será motivo de la suspensión inmediata del servicio y en caso", 10, 90);
            doc.text("de gravedad, podrá ser turnado a la Comisión de Honor del Consejo Técnico Consultivo Escolar.", 10, 100);
            
            // Información del alumno
            doc.text(`Nombre: ${nombre}`, 10, 120);
            doc.text(`Boleta: ${boleta}`, 10, 130);
            doc.setFont("Helvetica", "bold");
            doc.text(`Número de Casillero: ${casillero}`, 10, 140);
            doc.setFont("Helvetica", "normal");
            doc.text(`Periodo de Uso: ${periodo}`, 10, 150);
        
            // Texto del acuerdo
            doc.text("Condiciones de Uso del Casillero:", 10, 170);
            doc.text("1. No compartir el uso del casillero.", 10, 180);
            doc.text("2. Mantener el casillero limpio y en buen estado.", 10, 190);
            doc.text("3. Respetar las normativas establecidas por la institución.", 10, 200);
            doc.text("4. No almacenar alimentos o bebidas en el casillero.", 10, 210);
            doc.text("5. No almacenar objetos de valor en el casillero.", 10, 220);
            doc.text("6. No almacenar objetos prohibidos por la institución.", 10, 230);
        
            // Guardar el PDF
            doc.save(`${boleta}.pdf`);
        }
    
});
