document.addEventListener("DOMContentLoaded", function () {
    const editBtn = document.getElementById("edit-btn");
    const saveBtn = document.getElementById("save-btn");
    const sendBtn = document.getElementById("send-btn");
    const formElements = document.querySelectorAll("#edit-form .form-control");
    const lockerSection = document.getElementById("locker-section");
    const tipoSolicitudSelect = document.getElementById("tipoSolicitud");
    const datos = JSON.parse(localStorage.getItem("datosRegistro")) || {};

    // Cargar datos iniciales
    formElements.forEach((input) => {
        const id = input.id;

        if (id === "archivoHorario" || id === "archivoCredencial") {
            // Mostrar nombres de archivos desde localStorage
            const archivo = datos[id] || "Sin archivo seleccionado";
            input.nextElementSibling.textContent = archivo;
        } else if (id === "nombreCompleto") {
            // Combinar nombre, apellido paterno y materno
            input.value = `${datos.nombre || ""} ${datos.apellidoPaterno || ""} ${datos.apellidoMaterno || ""}`.trim();
        } else if (id === "tipoSolicitud") {
            // Seleccionar tipo de solicitud automáticamente
            if (datos.tipoSolicitud) {
                tipoSolicitudSelect.value = datos.tipoSolicitud === "Renovación" ? "Renovación" : "Primera";
            }
        } else {
            // Asignar el valor almacenado al campo
            input.value = datos[id] || "";
        }
    });

    // Mostrar sección de locker si es "Renovación"
    lockerSection.style.display = datos.tipoSolicitud === "Renovación" ? "block" : "none";

    tipoSolicitudSelect.addEventListener("change", function () {
        lockerSection.style.display = this.value === "Renovación" ? "block" : "none";
    });

    // Habilitar edición
    editBtn.addEventListener("click", function () {
        formElements.forEach((input) => input.disabled = false);
        editBtn.classList.add("d-none");
        saveBtn.classList.remove("d-none");
    });

    // Guardar cambios
    saveBtn.addEventListener("click", function () {
        const correo = document.getElementById("correo").value;
        if (!/^[a-zA-Z0-9._%+-]+@alumno\.ipn\.mx$/.test(correo)) {
            alert("Correo inválido.");
            return;
        }

        formElements.forEach((input) => {
            if (input.id === "archivoHorario" || input.id === "archivoCredencial") {
                datos[input.id] = input.files[0]?.name || datos[input.id];
                input.nextElementSibling.textContent = datos[input.id];
            } else {
                datos[input.id] = input.value;
            }
        });

        datos.tipoSolicitud = tipoSolicitudSelect.value;
        localStorage.setItem("datosRegistro", JSON.stringify(datos));
        formElements.forEach((input) => input.disabled = true);
        editBtn.classList.remove("d-none");
        saveBtn.classList.add("d-none");
        alert("Cambios guardados.");
    });

    // Enviar datos
    sendBtn.addEventListener("click", function () {
        alert("Datos enviados exitosamente.");
    });
});
