<?php
session_start();

if (!isset($_SESSION['boleta'])) {
    header("Location: comunidad.php");
    exit();
}

// Conexión a la base de datos
$conn = new mysqli("localhost", "root", "", "locker_e5");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$boleta = $_SESSION['boleta'];
$sql = "
    SELECT 
        s.datos_solicitud, 
        s.fecha, 
        s.comprobante, 
        c.id_casillero AS casillero, 
        a.nombre, 
        a.1erApellido AS primer_apellido, 
        a.2doApellido AS segundo_apellido
    FROM alumno_solicitud als
    INNER JOIN solicitud s ON als.id_solicitud = s.id_solicitud
    LEFT JOIN casillero c ON c.boleta = als.boleta
    INNER JOIN alumno a ON als.boleta = a.boleta
    WHERE als.boleta = '$boleta'
";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $datosUsuario = [
        'nombre' => $row['nombre'] . " " . $row['primer_apellido'] . " " . $row['segundo_apellido'],
        'boleta' => $boleta,
        'casillero' => $row['casillero']
    ];
    $tipoSolicitud = $row['datos_solicitud'];
    $comprobante = $row['comprobante'];

    // Mostrar texto según las condiciones
    $mostrarTexto = true;
    $mostrarTitulo = true;
    if ($tipoSolicitud === "Renovacion") {
        $mostrarTexto = false;
    }
    if (!empty($comprobante)) {
        $mostrarTexto = false;
        $mostrarTitulo = false;
    }
} else {
    echo "<script>alert('No se encontraron registros asociados.');</script>";
    $conn->close();
    session_destroy();
    exit();
}

// Subir el archivo de comprobante
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['comprobante']) && $_FILES['comprobante']['error'] === UPLOAD_ERR_OK) {
    $targetDir = "../uploads/comp/";
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true); // Crear la carpeta si no existe
    }
    $fileName = $boleta . "_" . basename($_FILES['comprobante']['name']);
    $targetFilePath = $targetDir . $fileName;

    if (move_uploaded_file($_FILES['comprobante']['tmp_name'], $targetFilePath)) {
        // Guardar la ruta del archivo en la base de datos usando la boleta
        $comprobanteRuta = $conn->real_escape_string($targetFilePath);
        $sqlUpdate = "
            UPDATE solicitud 
            SET comprobante = '$comprobanteRuta'
            WHERE id_solicitud = (
                SELECT id_solicitud 
                FROM alumno_solicitud 
                WHERE boleta = '$boleta'
            )
        ";
        if ($conn->query($sqlUpdate)) {
            echo "<script>alert('Comprobante subido y registrado correctamente.');</script>";
        } else {
            echo "<script>alert('Error al registrar el comprobante en la base de datos.');</script>";
        }
    } else {
        echo "<script>alert('Error al subir el archivo.');</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acuerdo de Conformidad</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container text-center my-5">
        <div class="row align-items-center justify-content-center">
            <div class="col-lg-7">
                <div class="card p-4">
                    <div class="card-body">
                        <?php if ($mostrarTitulo): ?>
                            <h2>Acuerdo de Conformidad</h2>
                        <?php endif; ?>
                        <?php if ($mostrarTexto): ?>
                            <p>El uso del casillero será para resguardar material bibliográfico, académico, de laboratorio, deportivo,
                                cultural y lo relacionado con tu actividad como estudiante dentro de la escuela.</p>
                            <p>Al aceptar las condiciones de uso del casillero, el alumno se compromete a:</p>
                            <ul class="text-start">
                                <li>No compartir el uso del casillero con otros estudiantes.</li>
                                <li>Mantener el casillero limpio y en buen estado.</li>
                                <li>No almacenar cualquier tipo de productos para comercialización.</li>
                                <li>No tener alimentos o bebidas que generen algún tipo de derramamiento o plaga.</li>
                                <li>No guardar bebidas alcohólicas o sustancias prohibidas.</li>
                                <li>No abrir el casillero por extravío de llaves sin antes reportarlo a la Subdirección Administrativa.</li>
                            </ul>
                            <p>No debes guardar en el interior objetos considerados de alto valor:</p>
                            <ul class="text-start">
                                <li>Laptops</li>
                                <li>Tablets</li>
                                <li>Alhajas</li>
                                <li>Dinero en efectivo</li>
                                <li>Cámaras fotográficas, etc.</li>
                            </ul>
                        <?php endif; ?>
                        <form method="POST" enctype="multipart/form-data" id="conformidad-form">
                            <div class="form-check mb-3 text-start">
                                <input type="checkbox" class="form-check-input" id="conformidad" name="conformidad">
                                <label class="form-check-label" for="conformidad">Estoy de acuerdo con las condiciones de uso del casillero.</label>
                            </div>
                            <div class="mb-3 text-start">
                                <label for="comprobante" class="form-label">Subir Comprobante de Pago:</label>
                                <input type="file" id="comprobante" name="comprobante" accept=".pdf" class="form-control">
                            </div>
                            <div class="d-grid">
                                <button type="button" id="generar-acuse" class="btn btn-dark" disabled>Generar Acuse</button>
                                <a href="logout.php" class="btn btn-secondary mt-2">Cerrar Sesión</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        const datosUsuario = <?php echo json_encode($datosUsuario, JSON_HEX_TAG); ?>;

        document.addEventListener("DOMContentLoaded", () => {
            const conformidadCheckbox = document.getElementById("conformidad");
            const comprobanteInput = document.getElementById("comprobante");
            const generarAcuseBtn = document.getElementById("generar-acuse");

            function validarFormulario() {
                const archivoSubido = comprobanteInput.files.length > 0;
                const conformidadMarcada = conformidadCheckbox.checked;
                generarAcuseBtn.disabled = !(archivoSubido && conformidadMarcada);
            }

            conformidadCheckbox.addEventListener("change", validarFormulario);
            comprobanteInput.addEventListener("change", validarFormulario);

            if ("<?php echo $comprobante; ?>" !== "") {
                generarAcuseBtn.disabled = false;
            }

            generarAcuseBtn.addEventListener("click", () => {
                const { boleta, nombre, casillero } = datosUsuario;
                const periodo = "Semestre 2024 - 2025/2 (Febrero - Agosto)";
                const fecha = new Date().toLocaleDateString();

                const { jsPDF } = window.jspdf;
                const doc = new jsPDF();
                doc.setFont("Helvetica", "bold");
                doc.setFontSize(15);
                doc.text("INSTITUTO POLITÉCNICO NACIONAL", 105, 20, { align: "center" });
                doc.text("ESCUELA SUPERIOR DE CÓMPUTO", 105, 28, { align: "center" });
                doc.setFontSize(13);
                doc.text("ASIGNACIÓN DE LOCKER", 105, 36, { align: "center" });
                doc.setFont("Helvetica", "normal");
                doc.text(`Fecha: ${fecha}`, 10, 50);
                doc.text(`Nombre Completo: ${nombre}`, 10, 60);
                doc.text(`Boleta: ${boleta}`, 10, 70);
                doc.setFont("Helvetica", "bold");
                doc.text(`Número de Casillero Asignado: ${casillero}`, 10, 80);
                doc.setFont("Helvetica", "normal");
                doc.text(`Periodo de Uso del Casillero: ${periodo}`, 10, 90);
                doc.setFontSize(14);
                doc.text("Condiciones de Uso del Casillero:", 10, 110);
                doc.setFontSize(12);
                doc.text("1. No compartir el uso del casillero.", 10, 130);
                doc.text("2. Mantener el casillero limpio y en buen estado.", 10, 140);
                doc.text("3. Respetar las normativas establecidas por la institución.", 10, 150);
                doc.text("4. No almacenar alimentos o bebidas en el casillero.", 10, 160);
                doc.text("5. No almacenar objetos de valor en el casillero.", 10, 170);
                doc.text("6. No almacenar objetos prohibidos por la institución.", 10, 180);
                doc.save(`${boleta}_acuse.pdf`);
                

            });
        });
    </script>
</body>
</html>
