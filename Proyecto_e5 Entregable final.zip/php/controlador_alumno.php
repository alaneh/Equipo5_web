<?php
    // El controlador se comunica con un modelo
    include_once 'user.php';
    $user = new user();
    if($_POST['funcion_login'] == 'login'){
        $usuario = $_POST['usuario'];
        $password = $_POST['password'];
        $user -> login_ing($usuario, $password);
    }
?>