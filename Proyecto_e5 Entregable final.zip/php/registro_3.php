<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resumen de Registro</title>
    <link rel="icon" href="../img/icon.webp" type="image/webp">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles_reg.css">
</head>
<body>
    <header class="header">
        <div class="header-overlay d-flex justify-content-between align-items-center px-4 py-3">
            <img src="../img/logoIPN.png" alt="IPN Logo" class="logo-ipn">
            <h1 class="responsive-header">Lockers for Stockers</h1>
            <img src="../img/logoESCOM.png" alt="ESCOM Logo" class="logo-escom">
        </div>
    </header>
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card p-4 rounded-card" id="summary-section">
                    <h2 class="text-center mb-4">Resumen del Registro</h2>
                    <form id="edit-form" method="POST" enctype="multipart/form-data" action="registro_3.php">
                        <!-- Número de Locker -->
                        <div class="mb-3">
                            <label for="numeroLocker" class="form-label">Número de Locker:</label>
                            <input type="text" class="form-control" id="numeroLocker" name="numeroLocker">
                        </div>
                        <!-- Tipo de Solicitud -->
                        <div class="mb-3">
                            <label for="tipoSolicitud" class="form-label">Tipo de Solicitud:</label>
                            <select class="form-control" id="tipoSolicitud" name="tipoSolicitud" >
                                <option value="Primera">Solicitar por primera vez</option>
                                <option value="Renovación">Renovación</option>
                            </select>
                        </div>
                        <!-- Campos Generales -->
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre:</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" >
                        </div>
                        <div class="mb-3">
                            <label for="apellidoPaterno" class="form-label">Primer Apellido:</label>
                            <input type="text" class="form-control" id="apellidoPaterno" name="apellidoPaterno" >
                        </div>
                        <div class="mb-3">
                            <label for="apellidoMaterno" class="form-label">Segundo Apellido:</label>
                            <input type="text" class="form-control" id="apellidoMaterno" name="apellidoMaterno" >
                        </div>
                        <div class="mb-3">
                            <label for="telefono" class="form-label">Teléfono:</label>
                            <input type="text" class="form-control" id="telefono" name="telefono">
                        </div>
                        <div class="mb-3">
                            <label for="correo" class="form-label">Correo:</label>
                            <input type="email" class="form-control" id="correo" name="correo">
                        </div>
                        <div class="mb-3">
                            <label for="boleta" class="form-label">Boleta:</label>
                            <input type="text" class="form-control" id="boleta" name="boleta">
                        </div>
                        <div class="mb-3">
                            <label for="estatura" class="form-label">Estatura:</label>
                            <input type="text" class="form-control" id="estatura" name="estatura">
                        </div>
                        <!-- Archivos -->
                        <div class="mb-3">
                            <label for="archivoCredencial" class="form-label">Credencial:</label>
                            <input type="file" class="form-control" id="archivoCredencial" name="archivoCredencial">
                            <span id="archivoCredencialInfo" class="form-text"></span>
                        </div>
                        <div class="mb-3">
                            <label for="archivoHorario" class="form-label">Horario:</label>
                            <input type="file" class="form-control" id="archivoHorario" name="archivoHorario">
                            <span id="archivoHorarioInfo" class="form-text"></span>
                        </div>
                        <!-- Usuario y Contraseña -->
                        <div class="mb-3">
                            <label for="usuario" class="form-label">Usuario:</label>
                            <input type="text" class="form-control" id="usuario" name="usuario">
                        </div>
                        <div class="mb-3">
                            <label for="clave" class="form-label">Contraseña:</label>
                            <input type="text" class="form-control" id="clave" name="clave">
                        </div>
                        <!-- Botones -->
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary" id="send-btn">Enviar</button>
                            <button type="button" id="limpiar-btn" class="btn btn-secondary">Limpiar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="../js/registro_3.js"></script>
</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn = new PDO("mysql:host=localhost;dbname=locker_e5", "root", "");
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Directorio para guardar los archivos subidos
        $uploadDir = '../uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $credencialPath = $uploadDir . basename($_FILES['archivoCredencial']['name']);
        $horarioPath = $uploadDir . basename($_FILES['archivoHorario']['name']);
        move_uploaded_file($_FILES['archivoCredencial']['tmp_name'], $credencialPath);
        move_uploaded_file($_FILES['archivoHorario']['tmp_name'], $horarioPath);

        // Recuperar datos del formulario
        $boleta = $_POST['boleta'];
        $nombre = $_POST['nombre'];
        $primerApellido = $_POST['apellidoPaterno'];
        $segundoApellido = $_POST['apellidoMaterno'];
        $telefono = $_POST['telefono'];
        $correo = $_POST['correo'];
        $estatura = $_POST['estatura'];
        $usuario = $_POST['usuario'];
        $clave = $_POST['clave'];
        $tipoSolicitud = $_POST['tipoSolicitud'];
        $numeroLocker = $_POST['numeroLocker'];

        // Insertar datos del alumno
        $stmtAlumno = $conn->prepare(
            "INSERT INTO alumno (boleta, nombre, 1erApellido, 2doApellido, telefono, correo, estatura, usuario, clave, credencial, horario) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $stmtAlumno->execute([$boleta, $nombre, $primerApellido, $segundoApellido, $telefono, $correo, $estatura, $usuario, $clave, $credencialPath, $horarioPath]);

        // Insertar solicitud
        $stmtSolicitud = $conn->prepare(
            "INSERT INTO solicitud (datos_solicitud, fecha, estado) 
            VALUES (?, NOW(), 'Pendiente')"
        );
        $stmtSolicitud->execute([$tipoSolicitud]);
        $idSolicitud = $conn->lastInsertId();

        // Relacionar boleta y solicitud
        $stmtRelacion = $conn->prepare(
            "INSERT INTO alumno_solicitud (boleta, id_solicitud) 
            VALUES (?, ?)"
        );
        $stmtRelacion->execute([$boleta, $idSolicitud]);

        // Actualizar casillero si es renovación
        if ($tipoSolicitud === 'Renovación') {
            $stmtCasillero = $conn->prepare(
                "UPDATE casillero 
                SET estado = 'Ocupado', boleta = ? 
                WHERE id_casillero = ?"
            );
            $stmtCasillero->execute([$boleta, $numeroLocker]);
        }

        echo "<div class='alert alert-success'>Registro completado exitosamente.</div>";
        echo "<script>window.location.href = '../index.html';</script>";
    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}
?>
