<?php
    class conexion{
        private $servidor = "localhost";
        private $data_base = "locker_e5";     // Nombre de la base de datos en phpMyAdmin
        private $puerto = 3306;                 // Puerto de MySQL en XAMPP
        private $charset = "utf8";
        private $user = 'root';
        private $clave = "";
        public $pdo = NULL;
        private $atributos = [PDO::ATTR_CASE => PDO::CASE_LOWER, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_ORACLE_NULLS => PDO::NULL_EMPTY_STRING, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ];
        // Método constructor
        function __construct(){
            $this -> pdo = new PDO("mysql:dbname={$this -> data_base};
                                    host = {$this -> servidor};
                                    port = {$this -> puerto};
                                    charset = {$this -> charset}",
                                $this -> user,
                                $this -> clave,
                                $this -> atributos);
        }
    }

// Crear conexión: $conn = new mysqli($host, $usuario, $clave, $baseDeDatos);

// Verificar conexión
/*
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
*/

// Establecer conjunto de caracteres: $conn->set_charset("utf8mb4");
?>
