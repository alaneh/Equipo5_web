<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header('Location: admin.php'); // Redirige a admin.php si no hay sesión activa
    exit();
}
// Conexión a la base de datos
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'locker_e5';

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die('Error de conexión: ' . $conn->connect_error);
}

$message = '';
$success = false;

// Operaciones CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['accion'])) {
        $accion = $_POST['accion'];

        if ($accion === 'agregar_casillero') {
            $idCasillero = $_POST['id_casillero'];
            $sqlInsertCasillero = "INSERT INTO casillero (id_casillero, detalles, estado) 
                                   VALUES ('$idCasillero', NULL, 'Disponible')";
            if ($conn->query($sqlInsertCasillero)) {
                $message = "Casillero $idCasillero agregado correctamente.";
                $success = true;
            } else {
                $message = "Error al agregar el casillero. Verifica que el ID no esté duplicado.";
            }
        }
    }
}

// Consultar solicitudes
$sqlSolicitudes = "
    SELECT 
        s.id_solicitud, 
        s.fecha, 
        s.estado, 
        s.datos_solicitud, 
        a.boleta, 
        CONCAT(a.nombre, ' ', a.1erApellido, ' ', a.2doApellido) AS nombre_completo
    FROM solicitud s
    INNER JOIN alumno_solicitud als ON s.id_solicitud = als.id_solicitud
    INNER JOIN alumno a ON als.boleta = a.boleta
";
$resultSolicitudes = $conn->query($sqlSolicitudes);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles_reg.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <!-- Encabezado -->
    <header class="header">
        <div class="header-overlay d-flex justify-content-between align-items-center px-4 py-3">
            <img src="../img/logoIPN.png" alt="IPN Logo" class="logo-ipn">
            <h1 class="responsive-header">Panel de Administración</h1>
            <img src="../img/logoESCOM.png" alt="ESCOM Logo" class="logo-escom">
        </div>
    </header>

    <!-- Contenido principal -->
    <div class="container my-5">
        <!-- Sección de solicitudes -->
        <div class="card p-4 rounded-card">
            <h2 class="text-center mb-4">Solicitudes Registradas</h2>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID Solicitud</th>
                        <th>Boleta</th>
                        <th>Nombre Completo</th>
                        <th>Fecha</th>
                        <th>Estado</th>
                        <th>Dato Solicitud</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($resultSolicitudes->num_rows > 0): ?>
                        <?php while ($row = $resultSolicitudes->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id_solicitud']; ?></td>
                                <td><?php echo $row['boleta']; ?></td>
                                <td><?php echo $row['nombre_completo']; ?></td>
                                <td><?php echo $row['fecha']; ?></td>
                                <td>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="accion" value="actualizar_solicitud">
                                        <input type="hidden" name="id_solicitud" value="<?php echo $row['id_solicitud']; ?>">
                                        <select name="estado" class="form-select">
                                            <option value="Pendiente" <?php if ($row['estado'] === 'Pendiente') echo 'selected'; ?>>Pendiente</option>
                                            <option value="Aprobada" <?php if ($row['estado'] === 'Aprobada') echo 'selected'; ?>>Aprobada</option>
                                            <option value="Rechazada" <?php if ($row['estado'] === 'Rechazada') echo 'selected'; ?>>Rechazada</option>
                                        </select>
                                </td>
                                <td>
                                    <select name="datos_solicitud" class="form-select">
                                        <option value="Primera" <?php if ($row['datos_solicitud'] === 'Primera') echo 'selected'; ?>>Primera</option>
                                        <option value="Renovación" <?php if ($row['datos_solicitud'] === 'Renovación') echo 'selected'; ?>>Renovación</option>
                                    </select>
                                </td>
                                <td>
                                    <button type="submit" class="btn btn-success btn-sm">Guardar</button>
                                    </form>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="accion" value="eliminar_solicitud">
                                        <input type="hidden" name="id_solicitud" value="<?php echo $row['id_solicitud']; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center">No hay solicitudes registradas</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Sección para agregar casilleros -->
        <div class="card p-4 rounded-card mt-5">
            <h2 class="text-center mb-4">Agregar Casillero</h2>
            <form method="POST">
                <input type="hidden" name="accion" value="agregar_casillero">
                <div class="mb-3">
                    <label for="id_casillero" class="form-label">ID Casillero</label>
                    <input type="text" id="id_casillero" name="id_casillero" class="form-control" required>
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Agregar Casillero</button>
                    <a href="casilleros.php" class="btn btn-secondary">Ir a Casilleros</a>
                        <form method="POST" action="logout.php" class="d-inline">
                            <button type="submit" class="btn btn-danger btn-sm">Cerrar Sesión</button>
                        </for>

                </div>
            </form>
        </div>
    </div>

    <!-- SweetAlert para mensajes -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            <?php if (!empty($message)): ?>
                Swal.fire({
                    icon: '<?php echo $success ? "success" : "error"; ?>',
                    title: '<?php echo $success ? "Éxito" : "Error"; ?>',
                    text: '<?php echo $message; ?>',
                });
            <?php endif; ?>
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
