<?php
session_start();
session_destroy(); // Destruye la sesión activa
header('Location: ../index.html'); // Redirige al inicio de sesión
exit();
?>
