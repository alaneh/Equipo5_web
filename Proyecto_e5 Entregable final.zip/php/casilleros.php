<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header('Location: admin.php'); // Redirige a admin.php si no hay sesión activa
    exit();
}

// Conexión a la base de datos
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'locker_e5';

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die('Error de conexión: ' . $conn->connect_error);
}

$message = '';
$success = false;

// Operaciones para casilleros
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['accion'])) {
        $accion = $_POST['accion'];

        if ($accion === 'asignar') {
            $idCasillero = $_POST['id_casillero'];
            $boleta = $_POST['boleta'];

            // Validar si la boleta existe
            $sqlValidarBoleta = "SELECT boleta FROM alumno WHERE boleta = '$boleta'";
            $result = $conn->query($sqlValidarBoleta);

            if ($result && $result->num_rows > 0) {
                // Asignar casillero
                $sqlAsignar = "UPDATE casillero 
                               SET estado = 'Ocupado', boleta = '$boleta' 
                               WHERE id_casillero = '$idCasillero'";
                if ($conn->query($sqlAsignar)) {
                    $message = "Casillero $idCasillero asignado correctamente al alumno con boleta $boleta.";
                    $success = true;
                } else {
                    $message = "Error al asignar el casillero. Intenta de nuevo.";
                }
            } else {
                $message = "La boleta ingresada no existe en la base de datos.";
            }
        } elseif ($accion === 'liberar') {
            $idCasillero = $_POST['id_casillero'];

            // Liberar casillero
            $sqlLiberar = "UPDATE casillero 
                           SET estado = 'Disponible', boleta = NULL 
                           WHERE id_casillero = '$idCasillero'";
            if ($conn->query($sqlLiberar)) {
                $message = "Casillero $idCasillero liberado correctamente.";
                $success = true;
            } else {
                $message = "Error al liberar el casillero. Intenta de nuevo.";
            }
        }
    }
}

// Consultar casilleros
$sqlCasilleros = "SELECT * FROM casillero";
$resultCasilleros = $conn->query($sqlCasilleros);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración de Casilleros</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles_reg.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <!-- Encabezado -->
    <header class="header">
        <div class="header-overlay d-flex justify-content-between align-items-center px-4 py-3">
            <img src="../img/logoIPN.png" alt="IPN Logo" class="logo-ipn">
            <h1 class="responsive-header">Administración de Casilleros</h1>
            <img src="../img/logoESCOMA.png" alt="ESCOM Logo" class="logo-escom">
        </div>
    </header>

    <!-- Contenido principal -->
    <div class="container my-5">
        <div class="card p-4 rounded-card">
            <h2 class="text-center mb-4">Casilleros Registrados</h2>
            <div class="row">
                <?php if ($resultCasilleros->num_rows > 0): ?>
                    <?php while ($row = $resultCasilleros->fetch_assoc()): ?>
                        <div class="col-md-3 mb-3">
                            <div class="card text-center 
                                <?php echo $row['estado'] === 'Disponible' ? 'bg-primary text-white' : 'bg-secondary text-white'; ?>">
                                <div class="card-body">
                                    <h5 class="card-title">Casillero <?php echo $row['id_casillero']; ?></h5>
                                    <p class="card-text">Estado: <?php echo $row['estado']; ?></p>
                                    <?php if ($row['estado'] === 'Disponible'): ?>
                                        <form method="POST">
                                            <input type="hidden" name="accion" value="asignar">
                                            <input type="hidden" name="id_casillero" value="<?php echo $row['id_casillero']; ?>">
                                            <input type="text" name="boleta" class="form-control mb-2" placeholder="Boleta del Alumno" required>
                                            <button type="submit" class="btn btn-light btn-sm">Asignar</button>
                                        </form>
                                    <?php else: ?>
                                        <p class="card-text">Asignado a: <?php echo $row['boleta']; ?></p>
                                        <form method="POST">
                                            <input type="hidden" name="accion" value="liberar">
                                            <input type="hidden" name="id_casillero" value="<?php echo $row['id_casillero']; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">Liberar</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="text-center">No hay casilleros registrados.</p>
                <?php endif; ?>
                <a href="Administrador.php" class="btn btn-secondary">Ir a Registros</a>
                <form method="POST" action="logout.php" class="d-inline">
    <button type="submit" class="btn btn-danger btn-sm">Cerrar Sesión</button>
</form>

            </div>
        </div>
    </div>

    <!-- SweetAlert para mensajes -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            <?php if (!empty($message)): ?>
                Swal.fire({
                    icon: '<?php echo $success ? "success" : "error"; ?>',
                    title: '<?php echo $success ? "Éxito" : "Error"; ?>',
                    text: '<?php echo $message; ?>',
                });
            <?php endif; ?>
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
