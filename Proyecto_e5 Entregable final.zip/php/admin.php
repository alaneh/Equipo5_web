<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Conexión a la base de datos
    $conn = new mysqli("localhost", "root", "", "locker_e5");
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    $usuario = $conn->real_escape_string($_POST['usuario']);
    $clave = $conn->real_escape_string($_POST['password']);

    // Validar usuario y contraseña desde la tabla 'admin'
    $sql = "SELECT * FROM admin WHERE usuario = '$usuario' AND clave = '$clave'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $_SESSION['admin'] = true; // Crear la sesión de administrador
        header('Location: Administrador.php'); // Redirigir al panel de administración
        exit();
    } else {
        $error = "Usuario o contraseña incorrectos.";
    }
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión - Administrador</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles_reg.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f8f9fa;
        }
        .card {
            width: 100%;
            max-width: 400px;
            padding: 20px;
        }
        .icon {
            font-size: 1.2rem;
        }
    </style>
</head>
<body>
    <div class="card shadow">
        <h3 class="text-center mb-4">Iniciar Sesión</h3>
        <form method="POST" action="">
            <!-- Usuario -->
            <div class="mb-3">
                <label for="usuario" class="form-label visually-hidden">Usuario</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="bi bi-person icon"></i></span>
                    <input type="text" id="usuario" name="usuario" class="form-control" placeholder="Usuario" required>
                </div>
            </div>
            <!-- Contraseña -->
            <div class="mb-3">
                <label for="password" class="form-label visually-hidden">Contraseña</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="bi bi-lock icon"></i></span>
                    <input type="password" id="password" name="password" class="form-control" placeholder="Contraseña" required>
                </div>
            </div>
            <!-- Botón de Iniciar sesión -->
            <div class="d-grid mb-2">
                <button type="submit" class="btn btn-dark" id="loginBtn">Iniciar sesión</button>
            </div>
        </form>
    </div>
</body>
</html>
