<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $servername = "127.0.0.1";
    $username = "root";
    $password = "";
    $dbname = "locker_e5";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    $boleta = $_POST['boleta'];
    $nombre = $_POST['nombre'];
    $apellidoPaterno = $_POST['apellidoPaterno'];
    $apellidoMaterno = $_POST['apellidoMaterno'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $estatura = $_POST['estatura'];
    $tipoSolicitud = $_POST['solicitud'];
    $estado = $tipoSolicitud === 'Renovación' ? 'Aprobada' : 'Pendiente';
    $fecha = date('Y-m-d H:i:s');

    // Verificar si la boleta ya existe
    $result = $conn->query("SELECT boleta FROM alumno WHERE boleta = '$boleta'");

    if ($result->num_rows > 0) {
        echo "<script>alert('La boleta ingresada ya está registrada.');</script>";
    } else {
        // Insertar datos en la tabla alumno
        $sqlAlumno = "INSERT INTO alumno (boleta, nombre, 1erApellido, 2doApellido, telefono, correo, estatura) 
                      VALUES ('$boleta', '$nombre', '$apellidoPaterno', '$apellidoMaterno', '$telefono', '$correo', '$estatura')";
        if ($conn->query($sqlAlumno) === TRUE) {
            // Crear solicitud
            $sqlSolicitud = "INSERT INTO solicitud (datos_solicitud, fecha, estado) VALUES ('$tipoSolicitud', '$fecha', '$estado')";
            if ($conn->query($sqlSolicitud) === TRUE) {
                $idSolicitud = $conn->insert_id;

                // Relacionar la solicitud con el alumno
                $sqlRelacion = "INSERT INTO alumno_solicitud (boleta, id_solicitud) VALUES ('$boleta', '$idSolicitud')";
                $conn->query($sqlRelacion);

                // Guardar la boleta en la sesión
                $_SESSION['boleta'] = $boleta;
                echo "<script>window.location.href = 'registro_2.php';</script>";
            } else {
                echo "<script>alert('Error al crear la solicitud: " . $conn->error . "');</script>";
            }
        } else {
            echo "<script>alert('Error al guardar los datos del alumno: " . $conn->error . "');</script>";
        }
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="icon" href="../img/icon.webp" type="image/webp">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles_reg.css">
</head>
<body>
    <header class="header">
        <div class="header-overlay d-flex justify-content-between align-items-center px-4 py-3">
            <img src="../img/logoIPN.png" alt="IPN Logo" class="logo-ipn" id="logo-ipn">
            <h1 class="responsive-header">Lockers for Stockers</h1>
            <img src="../img/logoESCOM.png" alt="ESCOM Logo" class="logo-escom">
        </div>
    </header>
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card p-4 rounded-card">
                    <form method="POST" action="">
                        <h2 class="text-center mb-4">Elige el tipo de solicitud</h2>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="radio" name="solicitud" id="renovacion" value="Renovación">
                            <label class="form-check-label" for="renovacion">Renovación</label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="radio" name="solicitud" id="nueva-solicitud" value="Nueva" required>
                            <label class="form-check-label" for="nueva-solicitud">Solicitar por primera vez</label>
                        </div>
                        <div class="mb-3 hidden">
                            <label for="numeroCasillero" class="form-label">Coloca el número de tu casillero anterior</label>
                            <input type="text" class="form-control" id="numeroCasillero" name="numeroCasillero">
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="nombre" class="form-label">Nombre(s)</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="apellidoPaterno" class="form-label">Primer Apellido</label>
                                <input type="text" class="form-control" id="apellidoPaterno" name="apellidoPaterno" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="apellidoMaterno" class="form-label">Segundo Apellido</label>
                                <input type="text" class="form-control" id="apellidoMaterno" name="apellidoMaterno" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="telefono" class="form-label">Teléfono</label>
                                <input type="tel" class="form-control" id="telefono" name="telefono" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="correo" class="form-label">Correo institucional</label>
                            <input type="email" class="form-control" id="correo" name="correo" required>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="boleta" class="form-label">Boleta</label>
                                <input type="text" class="form-control" id="boleta" name="boleta" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="estatura" class="form-label">Tu estatura</label>
                                <input type="text" class="form-control" id="estatura" name="estatura" required>
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-40">Siguiente</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="../js/registro_1.js"></script>
</body>
</html>

