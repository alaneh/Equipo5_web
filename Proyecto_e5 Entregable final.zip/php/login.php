<?php

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Conexión a la base de datos
        $conn = new PDO("mysql:host=localhost;dbname=locker_e5", "root", "");
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Recuperar datos del formulario
        $usuario = $_POST['usuario'];
        $clave = $_POST['password'];

        // Buscar usuario y contraseña en la tabla alumno
        $stmt = $conn->prepare(
            "SELECT a.boleta, s.datos_solicitud, s.fecha
            FROM alumno a
            INNER JOIN alumno_solicitud als ON a.boleta = als.boleta
            INNER JOIN solicitud s ON als.id_solicitud = s.id_solicitud
            WHERE a.usuario = :usuario AND a.clave = :clave"
        );
        $stmt->execute(['usuario' => $usuario, 'clave' => $clave]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $boleta = $result['boleta'];
            $tipoSolicitud = $result['datos_solicitud'];
            $fechaSolicitud = new DateTime($result['fecha']);
            $fechaActual = new DateTime();

            $_SESSION['boleta'] = $boleta;

            if ($tipoSolicitud === 'Renovación') {
                $intervalo = $fechaActual->diff($fechaSolicitud);
                if ($intervalo->days <= 1) {
                    header('Location: conformidad.html');
                    exit();
                } else {
                    echo "<script>alert('Tu solicitud de renovación ha expirado.');</script>";
                }
            } elseif ($tipoSolicitud === 'Primera') {
                $intervalo = $fechaActual->diff($fechaSolicitud);
                if ($intervalo->days < 2) {
                    echo "<script>alert('Aún estás en espera de asignación.');</script>";
                } else {
                    header('Location: conformidad.html');
                    exit();
                }
            }
        } else {
            echo "<script>alert('Usuario o contraseña incorrectos.');</script>";
        }
    } catch (Exception $e) {
        echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uso de Locker</title>
    <link rel="icon" href="../img/icon.webp" type="image/webp">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        #logo-ipn:hover {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-light bg-light border-bottom">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="../Index.html">
                <img src="../img/escom.png" alt="ESCOM Logo" width="40" height="40" class="me-2">
            </a>
            <span class="text-end d-flex align-items-center">
                <img src="../img/ipn.png" alt="IPN Logo" width="40" height="50" class="me-2" id="logo-ipn">
                <small>Instituto Politécnico Nacional <br>"La Técnica al Servicio de la Patria"</small>
            </span>
        </div>
    </nav>
    <!-- Contenido principal -->
    <div class="container container-fluid text-center my-5">
        <div class="row align-items-center justify-content-center">
            <!-- Imagen central -->
            <div class="col-lg-6 text-center mb-4 mb-lg-0 d-none d-md-flex">
                <img src="../img/Logotipo2.png" alt="Logo" class="logo" style="background-size: cover;">
            </div>
            <!-- Formulario -->
            <div class="col-lg-5">
                <div class="card p-4">
                    <div class="card-body">
                        <div class="text-center mb-3">
                            <h2>Iniciar sesión como Usuario</h2>
                        </div>
                        <form id="form-login" method="POST" action="">
                            <!-- Usuario -->
                            <div class="mb-3">
                                <label for="usuario" class="form-label visually-hidden">Usuario</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-person icon"></i></span>
                                    <input type="text" id="usuario" name="usuario" class="form-control" placeholder="Usuario" required>
                                </div>
                            </div>
                            <!-- Contraseña -->
                            <div class="mb-3">
                                <label for="password" class="form-label visually-hidden">Contraseña</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-lock icon"></i></span>
                                    <input type="password" id="password" name="password" class="form-control" placeholder="Contraseña" required>
                                </div>
                            </div>
                            <!-- Botón de Iniciar sesión -->
                            <div class="d-grid mb-2">
                                <button type="submit" class="btn btn-dark" id="loginBtn">Iniciar sesión</button>
                            </div>
                            <!-- Olvidé mi contraseña -->
                            <div class="text-center mb-3">
                                <a href="#" class="text-decoration-none">Olvidé mi contraseña</a>
                            </div>
                            <hr>
                            <!-- Botón de Registrarse dirige a form de solicitud casillero -->
                            <div class="d-grid">
                                <button type="button" class="btn btn-outline-dark">Registrarse</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <footer class="text-center bg-light py-3 border-top">
        <small>ESCOM • INSTITUTO POLITÉCNICO NACIONAL</small>
    </footer>
    <!-- Bootstrap JS -->
    <script src="../js/jquery.js"></script>
    <script src="../js/login.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
