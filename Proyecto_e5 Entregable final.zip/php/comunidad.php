<?php
session_start();

$response = ['status' => 'error', 'message' => 'Ocurrió un error desconocido.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Habilitar errores para depuración
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    try {
        // Conexión a la base de datos
        $conn = new mysqli("localhost", "root", "", "locker_e5");

        if ($conn->connect_error) {
            $response['message'] = "Error de conexión: " . $conn->connect_error;
            echo json_encode($response);
            exit();
        }

        // Recuperar datos del formulario
        $usuario = $conn->real_escape_string($_POST['usuario']);
        $clave = $conn->real_escape_string($_POST['password']);

        // Consulta SQL para verificar usuario y contraseña
        $sql = "
            SELECT a.boleta, a.usuario
            FROM alumno a
            WHERE a.usuario = '$usuario' AND a.clave = '$clave'
        ";

        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $_SESSION['boleta'] = $row['boleta'];
            $_SESSION['usuario'] = $row['usuario'];

            $response['status'] = 'success';
            $response['redirect'] = 'conformidad.php';
        } else {
            $response['message'] = "Usuario o contraseña incorrectos.";
        }

        $conn->close();
    } catch (Exception $e) {
        $response['message'] = "Error detectado: " . $e->getMessage();
    }

    echo json_encode($response);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uso de Locker</title>
    <link rel="icon" href="../img/icon.webp" type="image/webp">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        #logo-ipn:hover {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-light bg-light border-bottom">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="../Index.html">
                <img src="../img/escom.png" alt="ESCOM Logo" width="40" height="40" class="me-2">
            </a>
            <span class="text-end d-flex align-items-center">
                <img src="../img/ipn.png" alt="IPN Logo" width="40" height="50" class="me-2" id="logo-ipn">
                <small>Instituto Politécnico Nacional <br>"La Técnica al Servicio de la Patria"</small>
            </span>
        </div>
    </nav>
    
    <!-- Contenido principal -->
    <div class="container text-center my-5">
        <div class="row align-items-center justify-content-center">
            <!-- Imagen central -->
            <div class="col-lg-6 text-center mb-4 mb-lg-0">
                <img src="../img/Logotipo2.png" alt="Logo" class="logo">
            </div>
            <!-- Formulario -->
            <div class="col-lg-5">
                <div class="card p-4">
                    <div class="card-body">
                        <div class="text-center mb-3">
                            <h2>Iniciar sesión como Usuario</h2>
                        </div>
                        <form id="login-form">
                            <!-- Usuario -->
                            <div class="mb-3">
                                <label for="usuario" class="form-label visually-hidden">Usuario</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-person icon"></i></span>
                                    <input type="text" id="usuario" name="usuario" class="form-control" placeholder="Usuario" required>
                                </div>
                            </div>
                            <!-- Contraseña -->
                            <div class="mb-3">
                                <label for="password" class="form-label visually-hidden">Contraseña</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-lock icon"></i></span>
                                    <input type="password" id="password" name="password" class="form-control" placeholder="Contraseña" required>
                                </div>
                            </div>
                            <!-- Botón de Iniciar sesión -->
                            <div class="d-grid mb-2">
                                <button type="button" class="btn btn-dark" id="loginBtn">Iniciar sesión</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="text-center bg-light py-3 border-top">
        <small>ESCOM • INSTITUTO POLITÉCNICO NACIONAL</small>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('loginBtn').addEventListener('click', function () {
            const form = document.getElementById('login-form');
            const formData = new FormData(form);

            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    window.location.href = data.redirect;
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al procesar la solicitud. Intenta nuevamente.');
            });
        });
    </script>
</body>
</html>
