<?php
    include_once '../php/conexion.php';
    class user{
        var $objetos;
        public function __construct(){
            $data_base = new conexion();
            $this -> acceso = $data_base -> pdo;
        }
        function login_ing($usuario, $password){
            echo 'hi';
        }
    }
?>