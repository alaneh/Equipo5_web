<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="icon" href="../img/icon.webp" type="image/webp">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles_reg.css">
</head>
<body>
    <header class="header">
        <div class="header-overlay d-flex justify-content-between align-items-center px-4 py-3">
            <img src="../img/logoIPN.png" alt="IPN Logo" class="logo-ipn">
            <h1 class="responsive-header">Lockers for Stockers</h1>
            <img src="../img/logoESCOM.png" alt="ESCOM Logo" class="logo-escom">
        </div>
    </header>
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card p-4 rounded-card">
                <?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar que los archivos se hayan subido correctamente
    if (isset($_FILES['credencial']) && isset($_FILES['horario'])) {
        $uploadDir = '../uploads/';
        
        // Verificar si la carpeta "uploads" existe; si no, crearla
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Definir rutas de los archivos
        $credencialPath = $uploadDir . basename($_FILES['credencial']['name']);
        $horarioPath = $uploadDir . basename($_FILES['horario']['name']);

        // Mover los archivos a la carpeta uploads
        if (move_uploaded_file($_FILES['credencial']['tmp_name'], $credencialPath) &&
            move_uploaded_file($_FILES['horario']['tmp_name'], $horarioPath)) {

            // Simular almacenamiento temporal usando JSON
            $datosRegistro = [
                'usuario' => $_POST['usuario'],
                'clave' => $_POST['clave'],
                'credencial' => $credencialPath,
                'horario' => $horarioPath
            ];

            // Guardar los datos en una variable de sesión
            session_start();
            $_SESSION['datosRegistro'] = $datosRegistro;

            // Redirigir a registro_3.html
            header('Location: ../php/registro_3.php');
            exit();
        } else {
            echo "<div class='alert alert-danger'>Error al mover los archivos. Verifica los permisos de la carpeta uploads.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Error: No se recibieron los archivos correctamente.</div>";
    }
} else {
    echo "<div class='alert alert-danger'>Acceso no permitido.</div>";
}
?>

                    <form method="post" enctype="multipart/form-data">
                        <h2 class="text-center mb-4">Adjunta tus documentos</h2>
                        <div class="mb-3">
                            <label for="credencial" class="form-label">Adjunta tu credencial que te acredita como alumno del IPN</label>
                            <input type="file" class="form-control" id="credencial" name="credencial" required>
                        </div>
                        <div class="mb-3">
                            <label for="horario" class="form-label">Adjunta tu horario que te acredita como alumno del IPN</label>
                            <input type="file" class="form-control" id="horario" name="horario" required>
                        </div>
                        <div class="mb-3">
                            <label for="usuario" class="form-label">Usuario</label>
                            <input type="text" class="form-control" id="usuario" name="usuario" required>
                        </div>
                        <div class="mb-3">
                            <label for="clave" class="form-label">Contraseña</label>
                            <input type="password" class="form-control" id="clave" name="clave" required>
                        </div>
                        <div class="d-flex justify-content-between">
                            <button type="reset" class="btn btn-secondary">Limpiar</button>
                            <button type="submit" class="btn btn-primary">Registrar solicitud</button>
                        </div>                                             
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
    document.addEventListener("DOMContentLoaded", function () {
        const credencialInput = document.querySelector('#credencial');
        const horarioInput = document.querySelector('#horario');
        const usuarioInput = document.querySelector('#usuario');
        const claveInput = document.querySelector('#clave');

        const datos = JSON.parse(localStorage.getItem('datosRegistro')) || {};

        document.querySelector('form').addEventListener('submit', function () {
            datos.archivoCredencial = credencialInput.files[0]?.name || 'No subido';
            datos.archivoHorario = horarioInput.files[0]?.name || 'No subido';
            datos.usuario = usuarioInput.value;
            datos.clave = claveInput.value;
            localStorage.setItem('datosRegistro', JSON.stringify(datos));
        });
    });
    </script>
</body>
</html>
