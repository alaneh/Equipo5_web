$(document).ready(function () {
    $('#form-login').submit(function (e) {
        e.preventDefault(); // Previene el envío estándar del formulario

        let usuario = $('#usuario').val();
        let password = $('#password').val();

        $.ajax({
            url: 'login.php',
            type: 'POST',
            dataType: 'json',
            data: {
                usuario: usuario,
                password: password,
            },
            success: function (response) {
                if (response.status === 'success') {
                    window.location.href = response.redirect;
                } else if (response.status === 'error') {
                    alert(response.message);
                }
            },
            error: function () {
                alert('Error al intentar iniciar sesión. Intenta nuevamente.');
            },
        });
    });
});