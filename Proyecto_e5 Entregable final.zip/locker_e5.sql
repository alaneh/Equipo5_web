-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-01-2025 a las 19:00:51
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `locker_e5`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin`
--

CREATE TABLE `admin` (
  `num_empleado` bigint(20) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `1erApellido` varchar(200) NOT NULL,
  `2doApellido` varchar(200) DEFAULT NULL,
  `usuario` varchar(255) NOT NULL,
  `clave` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `admin`
--

INSERT INTO `admin` (`num_empleado`, `nombre`, `1erApellido`, `2doApellido`, `usuario`, `clave`) VALUES
(1001, 'Juan', 'Pérez', 'López', 'juan.perez@ipn.mx', 'Admin123'),
(1002, 'María', 'García', 'Sánchez', 'maria.garcia@ipn.mx', 'Admin456'),
(1003, 'Carlos', 'Hernández', 'Martínez', 'carlos.hernandez@ipn.mx', 'Admin789'),
(1004, 'Ana', 'Fernández', 'Gómez', 'ana.fernandez@ipn.mx', 'Admin101');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE `alumno` (
  `boleta` bigint(20) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `1erApellido` varchar(200) NOT NULL,
  `2doApellido` varchar(200) DEFAULT NULL,
  `correo` varchar(255) DEFAULT NULL,
  `telefono` int(20) DEFAULT NULL,
  `clave` varchar(255) DEFAULT NULL,
  `usuario` varchar(255) DEFAULT NULL,
  `horario` varchar(255) DEFAULT NULL,
  `credencial` varchar(255) DEFAULT NULL,
  `estatura` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`boleta`, `nombre`, `1erApellido`, `2doApellido`, `correo`, `telefono`, `clave`, `usuario`, `horario`, `credencial`, `estatura`) VALUES
(2000000001, 'Juan', 'Pérez', 'López', 'juan.perez@alumno.ipn.mx', 1234567890, 'clave123', 'juan.perez', 'Horario 1', 'credencial_juan.pdf', '1.75'),
(2000000002, 'Ana', 'Martínez', 'Hernández', 'ana.martinez@alumno.ipn.mx', 2147483647, 'clave456', 'ana.martinez', 'Horario 2', 'credencial_ana.pdf', '1.62'),
(2000000003, 'Luis', 'García', 'Ruiz', 'luis.garcia@alumno.ipn.mx', 1122334455, 'clave789', 'luis.garcia', 'Horario 3', 'credencial_luis.pdf', '1.80'),
(2000000004, 'María', 'Hernández', 'Díaz', 'maria.hernandez@alumno.ipn.mx', 2147483647, 'clave012', 'maria.hernandez', 'Horario 4', 'credencial_maria.pdf', '1.68'),
(2000000005, 'Carlos', 'Gómez', 'Jiménez', 'carlos.gomez@alumno.ipn.mx', 2147483647, 'clave345', 'carlos.gomez', 'Horario 5', 'credencial_carlos.pdf', '1.85'),
(2000000006, 'Sofía', 'Rodríguez', 'Vega', 'sofia.rodriguez@alumno.ipn.mx', 2147483647, 'clave678', 'sofia.rodriguez', 'Horario 6', 'credencial_sofia.pdf', '1.70'),
(2000000007, 'Miguel', 'López', 'Cruz', 'miguel.lopez@alumno.ipn.mx', 2147483647, 'clave901', 'miguel.lopez', 'Horario 7', 'credencial_miguel.pdf', '1.77'),
(2000000008, 'Laura', 'Ramírez', 'Torres', 'laura.ramirez@alumno.ipn.mx', 2147483647, 'clave234', 'laura.ramirez', 'Horario 8', 'credencial_laura.pdf', '1.65'),
(2000000009, 'Fernando', 'Cruz', 'Álvarez', 'fernando.cruz@alumno.ipn.mx', 2147483647, 'clave567', 'fernando.cruz', 'Horario 9', 'credencial_fernando.pdf', '1.82'),
(2000000010, 'Andrea', 'Morales', 'Pérez', 'andrea.morales@alumno.ipn.mx', 2147483647, 'clave890', 'andrea.morales', 'Horario 10', 'credencial_andrea.pdf', '1.60'),
(2000000011, 'Ricardo', 'Torres', 'Guzmán', 'ricardo.torres@alumno.ipn.mx', 2147483647, 'clave321', 'ricardo.torres', 'Horario 11', 'credencial_ricardo.pdf', '1.79'),
(2000000012, 'Paola', 'Díaz', 'Mendoza', 'paola.diaz@alumno.ipn.mx', 2147483647, 'clave654', 'paola.diaz', 'Horario 12', 'credencial_paola.pdf', '1.67'),
(2000000013, 'Diego', 'Martínez', 'Ortiz', 'diego.martinez@alumno.ipn.mx', 2147483647, 'clave987', 'diego.martinez', 'Horario 13', 'credencial_diego.pdf', '1.83'),
(2000000014, 'Claudia', 'Luna', 'Ríos', 'claudia.luna@alumno.ipn.mx', 2147483647, 'clave147', 'claudia.luna', 'Horario 14', 'credencial_claudia.pdf', '1.64'),
(2000000015, 'Héctor', 'Santos', 'Navarro', 'hector.santos@alumno.ipn.mx', 2147483647, 'clave258', 'hector.santos', 'Horario 15', 'credencial_hector.pdf', '1.78'),
(2000630015, 'Patricia', 'Escamilla', 'Miranda', 'example123@alumno.ipn.mx', 2147483647, '12344', 'PEM1', '../uploads/', '../uploads/', '1.65'),
(2013632200, 'Tania', 'Reyes', 'Rios', 'example123@alumno.ipn.mx', 2147483647, '12345', 'PEM', '../uploads/', '../uploads/', '1.75'),
(2023630464, 'Javier', 'Lopez', 'Chabelo', 'example123@alumno.ipn.mx', 2147483647, '123456', 'Usuario1', '../uploads/', '../uploads/', '2.01'),
(2023630465, 'Daniel', 'Lopez', 'Chabelo', 'example123@alumno.ipn.mx', 2147483647, '123456', 'Usuario2', '../uploads/', '../uploads/', '1.75'),
(2023630490, 'Daniel', 'Reyes', 'Chabelo', 'example123@alumno.ipn.mx', 2147483647, '123456', 'admin1', '../uploads/', '../uploads/', '1.75'),
(2024630220, 'Javier', 'Reyes', 'Perez', 'example123@alumno.ipn.mx', 2147483647, '12345', 'admin12345', '../uploads/', '../uploads/', '2'),
(2024630999, 'Luis Daniel', 'Reyes', 'Rios', 'luisda@alumno.ipn.mx', 2147483647, '12345', 'Usuario1234', '../uploads/', '../uploads/', '2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno_solicitud`
--

CREATE TABLE `alumno_solicitud` (
  `boleta` bigint(20) NOT NULL,
  `id_solicitud` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `alumno_solicitud`
--

INSERT INTO `alumno_solicitud` (`boleta`, `id_solicitud`) VALUES
(2000000001, 6),
(2000000002, 7),
(2000000003, 8),
(2000000004, 9),
(2000000005, 10),
(2000000006, 11),
(2000000007, 12),
(2000000008, 13),
(2000000009, 14),
(2000000010, 15),
(2000000011, 16),
(2000000012, 17),
(2000000013, 18),
(2000000014, 19),
(2000000015, 20),
(2000630015, 23),
(2013632200, 21),
(2023630464, 2),
(2023630465, 3),
(2023630490, 4),
(2024630220, 24),
(2024630999, 22);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `casillero`
--

CREATE TABLE `casillero` (
  `id_casillero` int(11) NOT NULL,
  `detalles` varchar(255) NOT NULL,
  `estado` enum('Disponible','Ocupado') NOT NULL DEFAULT 'Disponible',
  `boleta` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `casillero`
--

INSERT INTO `casillero` (`id_casillero`, `detalles`, `estado`, `boleta`) VALUES
(1, '', 'Disponible', NULL),
(2, '', 'Disponible', NULL),
(3, '', 'Ocupado', 2013632200),
(4, '', 'Disponible', NULL),
(5, '', 'Disponible', NULL),
(6, '', 'Disponible', NULL),
(7, '', 'Disponible', NULL),
(8, '', 'Disponible', NULL),
(9, '', 'Disponible', NULL),
(10, '', 'Disponible', NULL),
(11, '', 'Disponible', NULL),
(12, '', 'Ocupado', 2024630220),
(13, '', 'Disponible', NULL),
(14, '', 'Disponible', NULL),
(15, '', 'Disponible', NULL),
(16, '', 'Disponible', NULL),
(17, '', 'Disponible', NULL),
(18, '', 'Disponible', NULL),
(19, '', 'Disponible', NULL),
(20, '', 'Disponible', NULL),
(21, '', 'Disponible', NULL),
(22, '', 'Disponible', NULL),
(23, '', 'Disponible', NULL),
(24, '', 'Disponible', NULL),
(25, '', 'Disponible', NULL),
(26, '', 'Disponible', NULL),
(27, '', 'Disponible', NULL),
(28, '', 'Disponible', NULL),
(29, '', 'Disponible', NULL),
(30, '', 'Disponible', NULL),
(31, '', 'Disponible', NULL),
(32, '', 'Disponible', NULL),
(33, '', 'Disponible', NULL),
(34, '', 'Disponible', NULL),
(35, '', 'Disponible', NULL),
(36, '', 'Disponible', NULL),
(37, '', 'Disponible', NULL),
(38, '', 'Disponible', NULL),
(39, '', 'Disponible', NULL),
(40, '', 'Disponible', NULL),
(41, '', 'Disponible', NULL),
(42, '', 'Disponible', NULL),
(43, '', 'Disponible', NULL),
(44, '', 'Disponible', NULL),
(45, '', 'Disponible', NULL),
(46, '', 'Disponible', NULL),
(47, '', 'Disponible', NULL),
(48, '', 'Disponible', NULL),
(49, '', 'Disponible', NULL),
(50, '', 'Disponible', NULL),
(51, '', 'Disponible', NULL),
(52, '', 'Disponible', NULL),
(53, '', 'Disponible', NULL),
(54, '', 'Disponible', NULL),
(55, '', 'Disponible', NULL),
(56, '', 'Disponible', NULL),
(57, '', 'Disponible', NULL),
(58, '', 'Disponible', NULL),
(59, '', 'Disponible', NULL),
(60, '', 'Disponible', NULL),
(61, '', 'Disponible', NULL),
(62, '', 'Disponible', NULL),
(63, '', 'Disponible', NULL),
(64, '', 'Disponible', NULL),
(65, '', 'Disponible', NULL),
(66, '', 'Disponible', NULL),
(67, '', 'Disponible', NULL),
(68, '', 'Disponible', NULL),
(69, '', 'Disponible', NULL),
(70, '', 'Disponible', NULL),
(71, '', 'Disponible', NULL),
(72, '', 'Disponible', NULL),
(73, '', 'Disponible', NULL),
(74, '', 'Disponible', NULL),
(75, '', 'Disponible', NULL),
(76, '', 'Disponible', NULL),
(77, '', 'Disponible', NULL),
(78, '', 'Disponible', NULL),
(79, '', 'Disponible', NULL),
(80, '', 'Disponible', NULL),
(81, '', 'Disponible', NULL),
(82, '', 'Disponible', NULL),
(83, '', 'Disponible', NULL),
(84, '', 'Ocupado', 2000630015),
(85, '', 'Disponible', NULL),
(86, '', 'Disponible', NULL),
(87, '', 'Disponible', NULL),
(88, '', 'Disponible', NULL),
(89, '', 'Disponible', NULL),
(90, '', 'Disponible', NULL),
(91, '', 'Disponible', NULL),
(92, '', 'Disponible', NULL),
(93, '', 'Disponible', NULL),
(94, '', 'Disponible', NULL),
(95, '', 'Disponible', NULL),
(96, '', 'Disponible', NULL),
(97, '', 'Disponible', NULL),
(98, '', 'Disponible', NULL),
(99, '', 'Disponible', NULL),
(100, '', 'Disponible', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitud`
--

CREATE TABLE `solicitud` (
  `id_solicitud` int(11) NOT NULL,
  `datos_solicitud` enum('Primera','Renovacion','','') NOT NULL,
  `fecha` datetime NOT NULL,
  `estado` enum('Pendiente','Aprobada','Rechazada','') NOT NULL,
  `comprobante` varchar(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `solicitud`
--

INSERT INTO `solicitud` (`id_solicitud`, `datos_solicitud`, `fecha`, `estado`, `comprobante`) VALUES
(2, 'Primera', '2025-01-15 03:58:30', 'Pendiente', NULL),
(3, 'Primera', '2025-01-15 04:01:43', 'Pendiente', NULL),
(4, 'Primera', '2025-01-15 04:11:28', 'Pendiente', NULL),
(6, 'Primera', '2025-01-01 10:00:00', 'Pendiente', NULL),
(7, 'Renovacion', '2025-01-02 11:00:00', 'Aprobada', NULL),
(8, 'Primera', '2025-01-03 12:00:00', 'Pendiente', NULL),
(9, 'Renovacion', '2025-01-04 13:00:00', 'Rechazada', NULL),
(10, 'Primera', '2025-01-05 14:00:00', 'Pendiente', NULL),
(11, 'Renovacion', '2025-01-06 15:00:00', 'Aprobada', NULL),
(12, 'Primera', '2025-01-07 16:00:00', 'Pendiente', NULL),
(13, 'Renovacion', '2025-01-08 17:00:00', 'Pendiente', NULL),
(14, 'Primera', '2025-01-09 18:00:00', 'Rechazada', NULL),
(15, 'Renovacion', '2025-01-10 19:00:00', 'Aprobada', NULL),
(16, 'Primera', '2025-01-11 20:00:00', 'Pendiente', NULL),
(17, 'Renovacion', '2025-01-12 21:00:00', 'Aprobada', NULL),
(18, 'Primera', '2025-01-13 22:00:00', 'Pendiente', NULL),
(19, 'Renovacion', '2025-01-14 23:00:00', 'Rechazada', NULL),
(20, 'Primera', '2025-01-15 08:00:00', 'Pendiente', NULL),
(21, 'Renovacion', '2025-01-15 08:29:29', 'Pendiente', NULL),
(22, 'Renovacion', '2025-01-15 11:11:01', 'Pendiente', NULL),
(23, 'Primera', '2025-01-15 11:25:05', 'Pendiente', NULL),
(24, 'Renovacion', '2025-01-15 11:32:05', 'Pendiente', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`num_empleado`),
  ADD UNIQUE KEY `usuario_admin` (`usuario`);

--
-- Indices de la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD PRIMARY KEY (`boleta`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Indices de la tabla `alumno_solicitud`
--
ALTER TABLE `alumno_solicitud`
  ADD PRIMARY KEY (`boleta`,`id_solicitud`),
  ADD KEY `id_solicitud` (`id_solicitud`);

--
-- Indices de la tabla `casillero`
--
ALTER TABLE `casillero`
  ADD PRIMARY KEY (`id_casillero`),
  ADD KEY `fk_casillero_boleta` (`boleta`);

--
-- Indices de la tabla `solicitud`
--
ALTER TABLE `solicitud`
  ADD PRIMARY KEY (`id_solicitud`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `solicitud`
--
ALTER TABLE `solicitud`
  MODIFY `id_solicitud` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alumno_solicitud`
--
ALTER TABLE `alumno_solicitud`
  ADD CONSTRAINT `alumno_solicitud_ibfk_1` FOREIGN KEY (`boleta`) REFERENCES `alumno` (`boleta`),
  ADD CONSTRAINT `alumno_solicitud_ibfk_2` FOREIGN KEY (`id_solicitud`) REFERENCES `solicitud` (`id_solicitud`);

--
-- Filtros para la tabla `casillero`
--
ALTER TABLE `casillero`
  ADD CONSTRAINT `fk_casillero_boleta` FOREIGN KEY (`boleta`) REFERENCES `alumno` (`boleta`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
